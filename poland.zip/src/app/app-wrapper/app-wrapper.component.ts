import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-wrapper',
  templateUrl: './app-wrapper.component.html',
  styleUrls: ['./app-wrapper.component.sass']
})
export class AppWrapperComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
