import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empty-vacans',
  templateUrl: './empty-vacans.component.html',
  styleUrls: ['./empty-vacans.component.sass']
})
export class EmptyVacansComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
