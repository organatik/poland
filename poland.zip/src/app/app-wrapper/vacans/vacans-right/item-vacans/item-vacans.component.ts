import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-vacans',
  templateUrl: './item-vacans.component.html',
  styleUrls: ['./item-vacans.component.sass']
})
export class ItemVacansComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
