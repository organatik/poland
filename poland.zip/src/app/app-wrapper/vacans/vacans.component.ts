import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vacans',
  templateUrl: './vacans.component.html',
  styleUrls: ['./vacans.component.sass']
})
export class VacansComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
