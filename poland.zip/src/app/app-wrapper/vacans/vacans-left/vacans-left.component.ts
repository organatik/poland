import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vacans-left',
  templateUrl: './vacans-left.component.html',
  styleUrls: ['./vacans-left.component.sass']
})
export class VacansLeftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
