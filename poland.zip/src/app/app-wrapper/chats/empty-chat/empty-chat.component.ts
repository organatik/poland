import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empty-chat',
  templateUrl: './empty-chat.component.html',
  styleUrls: ['./empty-chat.component.sass']
})
export class EmptyChatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
