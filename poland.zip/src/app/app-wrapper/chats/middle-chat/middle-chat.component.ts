import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-middle-chat',
  templateUrl: './middle-chat.component.html',
  styleUrls: ['./middle-chat.component.sass']
})
export class MiddleChatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
